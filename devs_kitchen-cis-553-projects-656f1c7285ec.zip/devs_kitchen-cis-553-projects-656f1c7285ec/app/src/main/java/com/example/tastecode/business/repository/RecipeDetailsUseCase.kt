package com.example.tastecode.business.repository

import android.content.Context
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.rememberCoroutineScope
import com.example.tastecode.data.Recipe
import com.example.tastecode.data.db.RecipeDatabase
import com.example.tastecode.data.db.UserDataBase

class RecipeDetailsUseCase {

    fun markRecipeAsFavourite(
        context: Context,
        recipe: Recipe){

    }
}